﻿using Dapper;
using Dapper11feb.Entities;
using System.Data.SqlClient;

string connectionstr = "Data Source=AMIN_360\\SQLEXPRESS;Initial Catalog=Library;Integrated Security=True;Connect Timeout=30;Encrypt=True;TrustServerCertificate=True;";

var connection = new SqlConnection(connectionstr);
connection.Open();

//10 select query

//1
List<Book> books = connection.Query<Book>("Select * FROM Books").ToList();
foreach (var book in books)
{
    Console.WriteLine(book.Name);
}

//2
Console.WriteLine("\n\n\n");
var par = new DynamicParameters();
par.Add("@page",400);
List<Book> books2 = connection.Query<Book>("Select * FROM Books WHERE Pages > @page", par).ToList();

foreach (var book in books2)
{
    Console.WriteLine(book.Name+" => " + book.Pages);
}

//3
Console.WriteLine("\n\n\n");
List<Student> students3 = connection.Query<Student>
    ("Select S.FirstName FROM Students S LEFT JOIN S_Cards ON S_Cards.Id_Student = S.Id WHERE S.Id IS NOT NULL GROUP BY S.FirstName")
    .ToList();

foreach (var student in students3)
{
    Console.WriteLine(student.FirstName + " =>   kitab goturub");
}

//4
Console.WriteLine("\n\n\n");
List<Teacher> teachers4 = connection.Query<Teacher>("Select * FROM Teachers WHERE FirstName LIKE '%a%' ").ToList();
foreach(var teacher in teachers4)
{
    Console.WriteLine(teacher.FirstName);
}
//5
Console.WriteLine("\n\n\n");
int limit1 = 1;
int limit2 = 10;
var par5 = new DynamicParameters();
par5.Add("@limit1",limit1);
par5.Add("@limit2", limit2);
List<Author> authors = connection.Query<Author>("Select * FROM Authors WHERE Id BETWEEN @limit1 AND @limit2",par5).ToList();

foreach(var a in authors)
{
    Console.WriteLine(a.Id + " => " + a.FirstName);
}

//6
Console.WriteLine("\n\n\n");
List<Theme> themes6 = connection.Query<Theme>("Select * FROM Themes").ToList();
foreach (var t in themes6)
{
    Console.WriteLine(t.Name);
}

//7
Console.WriteLine("\n\n\n");
List<Lib> libs7 = connection.Query<Lib>("Select * FROM Libs").ToList();
foreach (var l in libs7)
{
    Console.WriteLine(l.FirstName + " " + l.LastName);
}

//8
Console.WriteLine("\n\n\n");
List<Group> gr8 = connection.Query<Group>("Select * FROM Groups").ToList();
foreach (var g in gr8)
{
    Console.WriteLine(g.Name);
}
//9
Console.WriteLine("\n\n\n");
List<Student> scards9 = connection.Query<Student>("Select Students.FirstName FROM S_Cards Sc INNER JOIN Students ON Sc.Id_Student = Students.Id WHERE DateIn IS NULL GROUP BY Students.FirstName").ToList();
foreach (var s in scards9)
{
    Console.WriteLine(s.FirstName + " => kitablari hele qaytarmayiblar");
}
//10
Console.WriteLine("\n\n\n");
int limit11 = 1;
int limit22 = 5;
var par10 = new DynamicParameters();
par10.Add("@limit11", limit11);
par10.Add("@limit22", limit22);
List<Department> dep = connection.Query<Department>("Select * FROM Departments WHERE Id BETWEEN @limit11 AND @limit22", par10).ToList();

foreach (var a in dep)
{
    Console.WriteLine(a.Name);
}
//10 insert query

//1
var parinsert1 = new DynamicParameters();
parinsert1.Add("@id1", 101);
parinsert1.Add("@fn1", "Amin");
parinsert1.Add("@ln1", "Ali");
string inserquery1 = "INSERT INTO Authors (Id, FirstName, LastName) VALUES(@id1,@fn1,@ln1)";
connection.Execute(inserquery1, parinsert1);

//2
var parinsert2 = new DynamicParameters();
parinsert2.Add("@id2", 101);
parinsert2.Add("@name2", "WebScience");
string insertquery2 = "INSERT INTO Themes (Id, Name) VALUES(@id2,@name2)";
connection.Execute(insertquery2, parinsert2);


//3
var parinsert3 = new DynamicParameters();
parinsert3.Add("@id3", 101);
parinsert3.Add("@name3", "New Faculty");
string insertquery3 = "INSERT INTO Faculties (Id, Name) VALUES(@id3,@name3)";
connection.Execute(insertquery3, parinsert3);

//4
var parinsert4 = new DynamicParameters();
parinsert4.Add("@id4", 101);
parinsert4.Add("@name4", "New Group");
parinsert4.Add("@idfaculty4", 101);
string insertquery4 = "INSERT INTO Groups (Id, Name,Id_Faculty) VALUES(@id4,@name4,@idfaculty4)";
connection.Execute(insertquery4, parinsert4);

//5
var parinsert5 = new DynamicParameters();
parinsert5.Add("@id5", 10);
parinsert5.Add("@fn5", "Nihat");
parinsert5.Add("@ln5", "SH");
string insertquery5 = "INSERT INTO Libs (Id,FirstName, LastName) VALUES (@id5,@fn5,@ln5)";
connection.Execute(insertquery5, parinsert5);

//6
var parinsert6 = new DynamicParameters();
parinsert6.Add("@id6", 100);
parinsert6.Add("@name6", "new Department");
string insertquery6 = "INSERT INTO Departments (Id, Name) VALUES (@id6,@name6)";
connection.Execute(insertquery6, parinsert6);

//7
var parinsert7 = new DynamicParameters();
parinsert7.Add("@id7", 100);
parinsert7.Add("@fn7", "Joseph");
parinsert7.Add("@ln7", "Blake");
parinsert7.Add("@iddep", 100);
string insertquery7 = "INSERT INTO Teachers (Id, FirstName, LastName, Id_Dep) VALUES" +
    "(@id7,@fn7,@ln7,@iddep)";
connection.Execute(insertquery7, parinsert7);

//8
var insertpar8 = new DynamicParameters();
insertpar8.Add("@id8", 100);
insertpar8.Add("@name8", "New Press");
string query8 = "INSERT INTO Press (Id, Name) VALUES (@id8,@name8)";
connection.Execute(query8, insertpar8);

//9
var insertpar9 = new DynamicParameters();
insertpar9.Add("@id9", 100);
insertpar9.Add("@name9", "New category");
string query9 = "INSERT INTO Categories (Id, Name) VALUES (@id9,@name9)";
connection.Execute(query9, insertpar9);

//10
var insertpar10 = new DynamicParameters();
insertpar10.Add("@fn10", "Revan");
insertpar10.Add("@ln10", "Revanov");
insertpar10.Add("@id10", 100);
insertpar10.Add("@term", 1);
insertpar10.Add("@idgroup", 1);
string query10 = "INSERT INTO Students (Id, FirstName, LastName, Id_Group, Term)" +
    "VALUES (@id10, @fn10, @ln10, @idgroup, @term)";
connection.Execute(query10, insertpar10);

//10 update query
var updatePar1 = new DynamicParameters();
updatePar1.Add("@id1", 101);
updatePar1.Add("@fn1", "Teze Amin");
updatePar1.Add("@ln1", "Teze Ali");
string updateQuery1 = "UPDATE Authors SET FirstName = @fn1, LastName = @ln1 WHERE Id = @id1";
connection.Execute(updateQuery1, updatePar1);

var updatePar2 = new DynamicParameters();
updatePar2.Add("@id2", 101);
updatePar2.Add("@name2", "Teze WebScience");
string updateQuery2 = "UPDATE Themes SET Name = @name2 WHERE Id = @id2";
connection.Execute(updateQuery2, updatePar2);

var updatePar3 = new DynamicParameters();
updatePar3.Add("@id3", 101);
updatePar3.Add("@name3", "Teze Faculty");
string updateQuery3 = "UPDATE Faculties SET Name = @name3 WHERE Id = @id3";
connection.Execute(updateQuery3, updatePar3);

var updatePar4 = new DynamicParameters();
updatePar4.Add("@id4", 101);
updatePar4.Add("@name4", "Teze Group");
updatePar4.Add("@idfaculty4", 1); 
string updateQuery4 = "UPDATE Groups SET Name = @name4, Id_Faculty = @idfaculty4 WHERE Id = @id4";
connection.Execute(updateQuery4, updatePar4);

var updatePar5 = new DynamicParameters();
updatePar5.Add("@id5", 10);
updatePar5.Add("@fn5", "Teze Nihat");
updatePar5.Add("@ln5", "Teze SH");
string updateQuery5 = "UPDATE Libs SET FirstName = @fn5, LastName = @ln5 WHERE Id = @id5";
connection.Execute(updateQuery5, updatePar5);


var updatePar6 = new DynamicParameters();
updatePar6.Add("@id6", 100);
updatePar6.Add("@name6", "Tez2e Department");
string updateQuery6 = "UPDATE Departments SET Name = @name6 WHERE Id = @id6";
connection.Execute(updateQuery6, updatePar6);


var updatePar7 = new DynamicParameters();
updatePar7.Add("@id7", 100);
updatePar7.Add("@fn7", "Teze Joseph");
updatePar7.Add("@ln7", "Teze2 Blake");
updatePar7.Add("@iddep7", 101);
string updateQuery7 = "UPDATE Teachers SET FirstName = @fn7, LastName = @ln7, Id_Dep = @iddep7 WHERE Id = @id7";
connection.Execute(updateQuery7, updatePar7);


var updatePar8 = new DynamicParameters();
updatePar8.Add("@id8", 100);
updatePar8.Add("@name8", "Tez2e Press");
string updateQuery8 = "UPDATE Press SET Name = @name8 WHERE Id = @id8";
connection.Execute(updateQuery8, updatePar8);


var updatePar9 = new DynamicParameters();
updatePar9.Add("@id9", 100);
updatePar9.Add("@name9", "Tdeze Category");
string updateQuery9 = "UPDATE Categories SET Name = @name9 WHERE Id = @id9";
connection.Execute(updateQuery9, updatePar9);


var updatePar10 = new DynamicParameters();
updatePar10.Add("@id10", 100);
updatePar10.Add("@fn10", "Teeze Revan");
updatePar10.Add("@ln10", "Teze Revanov");
updatePar10.Add("@idgroup10", 1);
updatePar10.Add("@term10", 2);
string updateQuery10 = "UPDATE Students SET FirstName = @fn10, LastName = @ln10, Id_Group = @idgroup10, Term = @term10 WHERE Id = @id10";
connection.Execute(updateQuery10, updatePar10);


//10 delete queryleri

//3
var deletePar3 = new DynamicParameters();
deletePar3.Add("@id3", 101);
string deleteQuery3 = "DELETE FROM Faculties WHERE Id = @id3";
connection.Execute(deleteQuery3, deletePar3);

//4
var deletePar4 = new DynamicParameters();
deletePar4.Add("@id4", 101);
string deleteQuery4 = "DELETE FROM Groups WHERE Id = @id4";
connection.Execute(deleteQuery4, deletePar4);

//5
var deletePar5 = new DynamicParameters();
deletePar5.Add("@id5", 10);
string deleteQuery5 = "DELETE FROM Libs WHERE Id = @id5";
connection.Execute(deleteQuery5, deletePar5);

//6
var deletePar6 = new DynamicParameters();
deletePar6.Add("@id6", 100);
string deleteQuery6 = "DELETE FROM Departments WHERE Id = @id6";
connection.Execute(deleteQuery6, deletePar6);

//7
var deletePar7 = new DynamicParameters();
deletePar7.Add("@id7", 100);
string deleteQuery7 = "DELETE FROM Teachers WHERE Id = @id7";
connection.Execute(deleteQuery7, deletePar7);


var deletePar8 = new DynamicParameters();
deletePar8.Add("@id8", 100);
string deleteQuery8 = "DELETE FROM Press WHERE Id = @id8";
connection.Execute(deleteQuery8, deletePar8);

var deletePar9 = new DynamicParameters();
deletePar9.Add("@id9", 100);
string deleteQuery9 = "DELETE FROM Categories WHERE Id = @id9";
connection.Execute(deleteQuery9, deletePar9);

var deletePar10 = new DynamicParameters();
deletePar10.Add("@id10", 100);
string deleteQuery10 = "DELETE FROM Students WHERE Id = @id10";
connection.Execute(deleteQuery10, deletePar10);


var deletePar1 = new DynamicParameters();
deletePar1.Add("@id1", 101);
string deleteQuery1 = "DELETE FROM Authors WHERE Id = @id1";
connection.Execute(deleteQuery1, deletePar1);


var deletePar2 = new DynamicParameters();
deletePar2.Add("@id2", 101);
string deleteQuery2 = "DELETE FROM Themes WHERE Id = @id2";
connection.Execute(deleteQuery2, deletePar2);

