﻿namespace Dapper11feb.Entities;
internal class T_card : BaseClass
{
    public int Id_Teacher { get; set; }
    public int Id_Book { get; set; }
    public int Id_Lib { get; set; }
    public DateTime DateIn { get; set; }
    public DateTime DateOut { get; set; }
}
