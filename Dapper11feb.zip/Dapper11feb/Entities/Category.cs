﻿namespace Dapper11feb.Entities;
internal class Category : BaseClass
{
    public string Name { get; set; }
}
