﻿namespace Dapper11feb.Entities;

internal class Teacher : BaseClass
{
    public string FirstName {  get; set; }
    public string LastName { get; set; }
    public int Id_Dep {  get; set; }
}
