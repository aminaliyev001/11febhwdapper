﻿namespace Dapper11feb.Entities;
public abstract class BaseClass
{
    public int Id {  get; set; }
}
