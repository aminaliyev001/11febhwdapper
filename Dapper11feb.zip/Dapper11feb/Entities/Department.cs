﻿namespace Dapper11feb.Entities;
internal class Department : BaseClass
{
    public string Name { get; set; }
}

