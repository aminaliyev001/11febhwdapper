﻿namespace Dapper11feb.Entities;
internal class Faculty : BaseClass
{
    public string Name { get; set; }
}
