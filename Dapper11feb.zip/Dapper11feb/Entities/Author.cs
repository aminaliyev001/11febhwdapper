﻿namespace Dapper11feb.Entities;
internal class Author : BaseClass
{
    public string FirstName { get; set;}
    public string LastName { get; set;}
}
