﻿namespace Dapper11feb.Entities;
internal class Press : BaseClass
{
    public string Name { get; set; }
}
