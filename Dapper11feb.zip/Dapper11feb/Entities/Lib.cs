﻿namespace Dapper11feb.Entities;

internal class Lib : BaseClass
{
    public string FirstName {  get; set; }
    public string LastName { get; set; }
}
