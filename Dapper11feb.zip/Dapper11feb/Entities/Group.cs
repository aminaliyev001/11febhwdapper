﻿namespace Dapper11feb.Entities;
internal class Group : BaseClass
{
    public string Name { get; set; }
    public int Id_Faculty {  get; set; }
}
