﻿namespace Dapper11feb.Entities;
internal class Theme : BaseClass
{
    public string Name { get; set; }  
}
